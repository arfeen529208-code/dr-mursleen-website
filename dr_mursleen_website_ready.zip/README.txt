DR. HAFIZ ANWAR UL MURSLEEN — WEBSITE
==========================================

This is a single-file responsive website.

What was changed:
- Removed the Gallery navigation option.
- Removed unused Gallery CSS.
- Improved mobile/browser performance.
- Added font preconnect and image loading hints.
- Added reduced-motion support.
- Reduced expensive blur effects on mobile.
- Preserved the existing doctor image and website functionality.
- Added safer external-link handling.

FREE PUBLIC LINK (Netlify):
1. Open https://app.netlify.com/drop
2. Sign in / create a free Netlify account.
3. Drag this folder's index.html (or the ZIP containing this folder) into the Netlify Drop area.
4. Netlify will generate a public HTTPS link.
5. That link can be sent to others and opens in Chrome/Safari/etc. on mobile and desktop.

FREE PUBLIC LINK (GitHub Pages):
1. Create a GitHub repository.
2. Upload index.html to the repository root.
3. Settings -> Pages -> Deploy from branch -> main -> /(root).
4. GitHub will generate an HTTPS website link.

Note: A permanent public URL requires a hosting provider. This package is deployment-ready.
